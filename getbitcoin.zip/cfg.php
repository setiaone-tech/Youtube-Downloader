<?php

//BAHAN YANG PERLU DIINSTAL DI TERMUX
//[1]. pkg install php
//[2]. pkg install tesseract
//[3]. pkg install imagemagick
//Sampai Sini sudah Paham Kan 
//Jangan Lupa Subscribe Chanel Penghasil Gratisa


$ua = "Mozilla/5.0 (Linux; Android 9; Redmi 6A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36";

$PHPSESSID = "PHPSESSID=m0eeab9siaqvhemh23mbvl0m5t";

$get_id = "get_id=145842";